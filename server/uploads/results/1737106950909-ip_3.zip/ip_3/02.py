'''
ASSUMPTION : 
    Constraint -> Time will be entered in valid 24 hrs format
'''


def time(t):
    t = t.split(":")
    return 3600*int(t[0]) + 60*int(t[1]) + int(t[2])


def my_time_module(T1, T2):
    return time(T2) > time(T1)


details = {}
f = open("data.txt", "r")
while True:
    data = f.readline().strip().split(", ")
    if data == ['']:
        break
    if data[0] not in details.keys():
        details[data[0]] = {"Crossing": [data[1]],
                            "Gate number": [data[2]], "Time": [data[3]]}
    else:
        details[data[0]]["Crossing"].append(data[1])
        details[data[0]]["Gate number"].append(data[2])
        details[data[0]]["Time"].append(data[3])
del details['TA']
f.close()
for i in details:
    time_list = list(details[i]["Time"]).copy()
    cross = list(details[i]["Crossing"])
    gate = list(details[i]["Gate number"])
    time_list.sort(key=lambda x: time(x))
    details[i]["Crossing"] = []
    details[i]["Gate number"] = []
    for j in time_list:
        details[i]["Crossing"].append(cross[list(details[i]["Time"]).index(j)])
        details[i]["Gate number"].append(
            gate[list(details[i]["Time"]).index(j)])
    details[i]["Time"] = time_list
m_d = {}
for i in details.keys():
    for ind in range(len(details[i]["Crossing"])):
        if i not in m_d.keys():
            m_d[i] = {"Crossing": [details[i]["Crossing"][ind]], "Gate number": [
                details[i]["Gate number"][ind]], "Time": [details[i]["Time"][ind]]}
        elif details[i]["Crossing"][ind] == "ENTER" == m_d[i]["Crossing"][-1]:
            continue
        elif details[i]["Crossing"][ind] == "EXIT" == m_d[i]["Crossing"][-1]:
            m_d[i]["Crossing"][-1] = "EXIT"
            m_d[i]["Gate number"][-1] = details[i]["Gate number"][ind]
            m_d[i]["Time"][-1] = details[i]["Time"][ind]
        else:
            m_d[i]["Crossing"].append(details[i]["Crossing"][ind])
            m_d[i]["Time"].append(details[i]["Time"][ind])
            m_d[i]["Gate number"].append(details[i]["Gate number"][ind])
details = m_d
while True:
    n = int(input("enter n : "))
    if n == 1:
        tester, condition = '', True
        name = input("Enter name :")
        current = input("Enter current time in 24 hrs format : ")
        if name in details.keys():
            print("Crossing  Gate Timing")
            for i in details[name].values():
                for j in range(len(details[name]["Crossing"])):
                    if details[name]["Crossing"][j] == "ENTER":
                        print(details[name]['Crossing'][j], end="     ")
                    else:
                        print(details[name]['Crossing'][j], end="      ")
                    print(details[name]["Gate number"][j], end="    ")
                    print(details[name]["Time"][j], end=" ")
                    print(end="\n")
                    if my_time_module(current, details[name]["Time"][j]) and condition:
                        condition = False
                    else:
                        tester = details[name]["Crossing"][j]
            if tester == "ENTER":
                print("Yes, He was in campus at that time")
            else:
                print("Not in campus at that time")
            continue
        else:
            print("This student has neither entered nor exited the campus")
            continue
    elif n == 2:
        balak = []
        start_time = input("enter start time : ")
        end_time = input("enter end time : ")
        for i, j in details.items():
            for s, k in enumerate(j["Time"]):
                if my_time_module(start_time, k) and my_time_module(k, end_time):
                    balak.append([i, j["Crossing"][s], j["Gate number"][s], k])
        b = sorted(balak, key=lambda x: x[3])
        with open("02_details.txt", "w") as f:
            for i in b:
                for j in i:
                    f.write(j)
                    f.write(" ")
                f.write('\n')
        continue
    elif n == 3:
        entries = 0
        exits = 0
        gate = input("Enter a gate no.")
        if (not gate.isdigit()):
            print("gate number was invalid")
            continue
        for i in details.values():
            for ind, j in enumerate(i["Gate number"]):
                if j == gate and i["Crossing"][ind] == "ENTER":
                    entries += 1
                elif (j == gate and i["Crossing"][ind] == "EXIT"):
                    exits += 1
        print("Entries made in the day : ", entries)
        print("Exists made in the day : ", exits)
        continue
    else:
        break
