import time
begin  =time.time()
def fn(l):
    d = []
    for i in range(len(l)-1):
        d.append([abs(l[i]-l[i+1]),l[i],l[i+1]]) 
    d = sorted(d,key = lambda x:x[0])
    try:   
        return (d[-1][1] + d[-1][2])/2
    except Exception as e:
        return -1
def policy(all_scores):
    cutoff_list ={}
    rule = {80:[], 65:[], 50:[], 40:[]}
    for i in all_scores:
        for j in rule.keys():
            if(j-2<i<j+2):
                rule[j].append(i)
    for i,j in enumerate(rule.items()):
        if fn(j[1])!=-1:
            cutoff_list[chr(97+i).upper()] = fn(j[1])
        else:
            cutoff_list[chr(97+i).upper()] = j[0]
    return cutoff_list
def calc(mark):
    score = 0
    for i in range(len(mark)):
        score += mark[i]*course["IP"]["assessments"][i][1]/course["IP"]["max_marks"][i]
    return score
def grading(s,l):
    criterea = policy(l)
    lo = list(criterea.keys())
    l = list(criterea.values())
    for i in range(len(criterea)-1):
        if l[i+1]<s<=l[i]:
            return lo[i+1]
    if s<l[-1]:
        return "F"
    else:
        return "A"

course = {"IP": {"assessments": [
    ("labs", 30), ("midsem", 15), ("assignments", 30), ("endsem", 25)], "credits": 4, "max_marks": [100,100,100,100]}}
f = open("marks.txt", "r")
Students = {}
while True:
    data = f.readline().strip().split(",")
    if data == ['']:
        break
    Students[data[0]] = {}
    Students[data[0]]["MarksList"] = []
    for i in data:
        Students[data[0]]["MarksList"].append(float(i))
    Students[data[0]]["MarksList"].pop(0)
f.close()
all_scores = []
for i in Students.values():
    i["marks"] = calc(i["MarksList"])
    all_scores.append(float(i['marks']))
all_grades = []
for i in Students.values():
    i["grade"] = grading(i["marks"],all_scores)
    all_grades.append(i["grade"])
while True:
    n = input("enter query : ")
    if n=='1':
        print("Summary of the course : ")
        print("course name =","IP")
        print("course credits =",course['IP']['credits'])
        print("course assessments =",course['IP']['assessments'])
        print("max marks in respective assesments =",course['IP']['max_marks'])
        print("Cutoff dictionary for grades =",policy(all_scores))
        print("*************************************")
        print("A's : ",all_grades.count("A"))
        print("B's : ",all_grades.count("B"))
        print("C's : ",all_grades.count("C"))
        print("D's : ",all_grades.count("D"))
        print("F's : ",all_grades.count("F"))
        print("*************************************")
        continue
    if n == '2':
        with open("record_05.txt","w") as f:
            for i in Students.keys():
                f.write(i + " " +str(Students[i]["marks"]) +" "+ Students[i]["grade"])
                f.write("\n")
        continue
    if n=='3':
        st = input("Enter student roll no. : ")
        for i in Students.keys():
            if i==st:
                print("roll no =",i)
                print("marks in different assessments :")
                for j in range(len(Students[i]["MarksList"])):
                    print("\t",course["IP"]['assessments'][j][0],Students[i]["MarksList"][j])
                print("Total marks =",Students[i]["marks"])
                print("Grade =",Students[i]["grade"])
                break
        continue
    elif(n!=""):
        print("Enter valid input")
        continue
    else:              
        break
print("PROGRAM ENDS")
end = time.time()