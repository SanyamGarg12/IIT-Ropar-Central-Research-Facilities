def d_star(number, n):
    if n == 1:
        return "* "*(2*number)
    return "* "*(number+1-n) + "  "*(2*n-2) + "* "*(number+1-n) + "\n" + d_star(number, n-1)


def up_star(number, n):
    if n == number:
        return "* "+"  "*(2*number - 2) + "* "
    return "* "*(number + 1 - n) + "  "*(2*n-2) + "* "*(number + 1 - n) + "\n" + up_star(number, n+1)


num = int(input())
if num>1:
    print(up_star(num, 1)+"\n"+d_star(num, num-1))
elif(num==1):
    print("* *")
else:
    print("Enter number greater than 0 for a star pattern") 