import time
begin = time.time()
def fn(l):
    d = []
    for i in range(len(l)-1):
        d.append([abs(l[i]-l[i+1]),l[i],l[i+1]]) 
    d = sorted(d,key = lambda x:x[0])
    try:   
        return (d[-1][1] + d[-1][2])/2
    except Exception as e:
        return -1
def policy(all_scores):
    cutoff_list ={}
    rule = {80:[], 65:[], 50:[], 40:[]}
    for i in all_scores:
        for j in rule.keys():
            if(j-2<i<j+2):
                rule[j].append(i)
    for i,j in enumerate(rule.items()):
        if fn(j[1])!=-1:
            cutoff_list[chr(97+i).upper()] = fn(j[1])
        else:
            cutoff_list[chr(97+i).upper()] = j[0]
    return cutoff_list
all_scores = []
class student:
    def __init__(self,roll, marks_list):
        self.roll_no = roll
        self.marks_list = marks_list

    def evaluation(self, course):
        self.score = 0
        for i in range(len(self.marks_list)):
            self.score+=self.marks_list[i]*course.assessments[i][1]/course.max_marks[i]
        all_scores.append(self.score)
    def grade(self):
        criterea = policy(all_scores)
        lo = list(criterea.keys())
        l = list(criterea.values())
        for i in range(len(criterea)-1):
            if l[i+1]<self.score<=l[i]:
                return lo[i+1]
        if self.score<l[-1]:
            return "F"
        else:
            return "A"
class course:
    def __init__(self, name, credits, assessments, max_marks):
        self.name = name
        self.credits = credits
        self.assessments = assessments
        self.max_marks = max_marks
credits = 4
max_marks = [100,100,100,100]
assessments = [("labs", 30), ("midsem", 15),
               ("assignments", 30), ("endsem", 25)]
name = "IP"
IP = course(name, credits, assessments, max_marks)
# other_course = input("Wanna add another course ?(yes/no)")
f = open("marks.txt", "r")
marks = []
while True:
    data = f.readline().strip().split(",")
    if data == ['']:
        break
    marks.append(data)
for i in range(len(marks)):
    l = []
    for j in marks[i][1:]:
        l.append(float(j))
    marks[i][0] = student(marks[i][0],l)
    marks[i][0].evaluation(IP)
f.close()
combined_data = {}
# print(all_scores)
# print(policy(all_scores))
for i in range(len(marks)):
    combined_data[marks[i][0].roll_no] = marks[i][0].grade()
grades = list(combined_data.values())
while True:
    n = input("enter query : ")
    if n=='1':
        print("Summary of the course : ")
        print("course name =",IP.name)
        print("course credits =",IP.credits)
        print("course assessments =",IP.assessments)
        print("max marks in respective assesments =",IP.max_marks)
        print("Cutoff dictionary for grades =",policy(all_scores))
        print("*************************************")
        print("A's : ",grades.count("A"))
        print("B's : ",grades.count("B"))
        print("C's : ",grades.count("C"))
        print("D's : ",grades.count("D"))
        print("F's : ",grades.count("F"))
        print("*************************************")
        continue
    if n == '2':
        with open("record_04.txt","w") as f:
            for i in marks:
                f.write(i[0].roll_no + " " +str(i[0].score) +" "+ i[0].grade())
                f.write("\n")
        continue
    if n=='3':
        st = input("Enter student roll no. : ")
        for i in marks:
            if i[0].roll_no==st:
                print("roll no =",i[0].roll_no)
                print("marks in different assessments :")
                for j in range(len(i[0].marks_list)):
                    print("\t",IP.assessments[j][0],i[0].marks_list[j])
                print("Total marks =",i[0].score)
                print("Grade =",i[0].grade())
                break
        continue
    elif(n!=""):
        print("Enter valid input")
        continue
    else:
        break
print("PROGRAM ENDS")
end = time.time()