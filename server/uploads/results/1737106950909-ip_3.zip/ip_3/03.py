f = open(f"File0{1}.txt", 'r')
all = ''
t = [';', ',', '.', ':']
f2 = 0
f30 = 0
f31 = 0
f4 = 0
sex = 0
f5 = 0
test = True
s = ' '
d = {}
t = ''
while (1):
    i = f.read(1)
    if i == '':
        break
    if i == s[-1] and i in t and i != s[-2]:
        f4 += 1
    if i != ".":
        test = True
    if i == "." and test:
        f30 += 1
        test = False
        sex = len(t.split())
        if sex>35 or sex<5:
            f31+=1
        sex = 0
    if test:
        t+=i
    s += i.lower()
s = s.replace(";", "")
s = s.replace(":", "")
s = s.replace(".", "")
s = s.replace(",", "")
s = s.split()
f.close()
for i in s:
    if i not in d:
        d[i] = 1
    else:
        d[i] += 1
d = sorted(d.items(), key=lambda x: x[1])
f1 = len(d)/len(s)
for i in range(0, 5):
    f2 += d[-1-i][1]
f2 = f2/len(s)
f4 = f4/len(s)
if len(s) >= 750:
    f5 = 1
f3 = f31/f30
# print("f1",f1)
# print("f2",f2)
# print("f3",f3)
# print("f4",f4)
# print("f5",f5)
print( 4 + f1*6 + f2*6 -f3 - f4 - f5)